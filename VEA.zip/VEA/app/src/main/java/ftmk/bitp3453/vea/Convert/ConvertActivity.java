package ftmk.bitp3453.vea.Convert;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MediaController;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import ftmk.bitp3453.vea.R;

public class ConvertActivity extends AppCompatActivity {

    //layout element
    private TextView videoFileName;
    private VideoView videoView;
    private Button selectVideo,convertBtn;
    private List<String> format_extensions = new ArrayList<String>();
    String src_path, extension, onlyName;
    private ArrayAdapter<String> fAdapter;
    private Spinner formatSpinner;
    //feedback
    public static final int RETURN_CODE_SUCCESS = 0;
    public static final int RETURN_CODE_CANCEL = 255;
    //progress element
    ProgressDialog progressDialog;
    Handler handler =new Handler();;
    long timeInMillisec;
    int REQ_CODE_EXTERNAL_STORAGE_PERMISSION = 23;
    int last_action = 3;
    //
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQ_CODE_EXTERNAL_STORAGE_PERMISSION && grantResults.length >0 &&grantResults[0] == PackageManager.PERMISSION_GRANTED){

        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert);

        // calling the action bar
        ActionBar actionBar = getSupportActionBar();
        // showing the back button in action bar
        actionBar.setDisplayHomeAsUpEnabled(true);
        //set icon
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.drawable.ic_convert);


        videoFileName = findViewById(R.id.videoName);
        convertBtn = findViewById(R.id.convertBtn);
        selectVideo = findViewById(R.id.selectBtn);
        formatSpinner = findViewById(R.id.fSpinner);
        videoView = findViewById(R.id.videoView);
        MediaController mc = new MediaController(this);
        mc.setAnchorView(videoView);
        mc.setMediaPlayer(videoView);
        videoView.setMediaController(mc);
        selectVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // create an intent to retrieve the video
                // file from the device storage
                ActivityCompat.requestPermissions(ConvertActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_CODE_EXTERNAL_STORAGE_PERMISSION);

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("video/*");
                startActivityForResult(intent, 123);
            }
        });

        convertBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (src_path!=null&&formatSpinner.getSelectedItem().toString()!=null) {
                    LayoutInflater inflater = getLayoutInflater();
                    final View view = inflater.inflate(R.layout.activity_dialog, null);
                    AlertDialog alertDialog = new AlertDialog.Builder(ConvertActivity.this).create();
                    alertDialog.setTitle("Convert Video");
                    alertDialog.setCancelable(false);
                    final EditText et_FileName = (EditText) view.findViewById(R.id.et_FileName);
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "save", (dialog, which) -> {
                        convertVideo(et_FileName.getText().toString());
                    });
                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "cancel", (dialog, which) -> alertDialog.dismiss());
                    alertDialog.setView(view);
                    alertDialog.show();
                }else if(src_path==null)
                    Toast.makeText(ConvertActivity.this, "Please Choose a Video", Toast.LENGTH_SHORT).show();
                else{
                    Toast.makeText(ConvertActivity.this, "Please Choose a Convert Format", Toast.LENGTH_SHORT).show();

                }
            }
        });
        //setting progress dialog
        progressDialog = new ProgressDialog(ConvertActivity.this);
        progressDialog.setMax(100);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setTitle("Converting");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setCancelable(false);
        progressDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                progressDialog.dismiss();//dismiss dialog
                FFmpeg.cancel();
            }
        });
    }

    // this event will enable the back
    // function to the button on press
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void format_spinner_populator() {
        format_extensions.clear();
        if (extension.equals("mp4")) {
            format_extensions.add("avi");
            format_extensions.add("flv");
            format_extensions.add("mov");
            format_extensions.add("mkv");
            format_extensions.add("3gp");
        } else if (extension.equals("avi")) {
            format_extensions.add("mp4");
            format_extensions.add("flv");
            format_extensions.add("mov");
            format_extensions.add("mkv");
            format_extensions.add("3gp");
        } else if (extension.equals("flv")) {
            format_extensions.add("mp4");
            format_extensions.add("avi");
            format_extensions.add("mov");
            format_extensions.add("mkv");
            format_extensions.add("3gp");
        } else if (extension.equals("mov")) {
            format_extensions.add("mp4");
            format_extensions.add("avi");
            format_extensions.add("flv");
            format_extensions.add("mkv");
            format_extensions.add("3gp");
        } else if (extension.equals("mkv")) {
            format_extensions.add("mp4");
            format_extensions.add("avi");
            format_extensions.add("flv");
            format_extensions.add("mov");
            format_extensions.add("3gp");
        }else if (extension.equals("3gp")) {
            format_extensions.add("mp4");
            format_extensions.add("avi");
            format_extensions.add("flv");
            format_extensions.add("mov");
            format_extensions.add("mkv");
        }
        else{
            Toast.makeText(ConvertActivity.this, "Format is not supported", Toast.LENGTH_SHORT).show();

        }

    }
    private void stringPuller(String path) {

        int i = 1;
        while (!path.substring(path.lastIndexOf(".") - i).startsWith("/")) {
            onlyName = path.substring(path.lastIndexOf(".") - i);
            i++;
        }
    }


    private void extensionPuller(String path) {
        extension = path.substring(path.lastIndexOf(".") + 1);
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 123) {
                if (data != null) {
                    // get the video Uri
                    Uri uri = data.getData();
                    try {
                        // get the file from the Uri using getFileFromUri() method present
                        // in FileUils.java
                        File video_file = FileUtils.getFileFromUri(this, uri);


                        // get the absolute path of the video file. We will require
                        // this as an input argument in
                        // the ffmpeg command.
                        this.src_path = video_file.getAbsolutePath();
                        videoView.setVideoURI(uri);
                        extensionPuller(src_path);
                        stringPuller(src_path);
                        videoFileName.setText(onlyName);
                        //onlyName = onlyName.replaceFirst("[.][^.]+$", "");
                        format_spinner_populator();
                        fAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, format_extensions);
                        fAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        formatSpinner.setAdapter(fAdapter);
                        fAdapter.notifyDataSetChanged();
                        MediaMetadataRetriever retriever = new MediaMetadataRetriever();

                        //use one of overloaded setDataSource() functions to set your data source
                        retriever.setDataSource(ConvertActivity.this,  Uri.parse(src_path));
                        String time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                        timeInMillisec = Long.parseLong(time );
                        retriever.release();

                    } catch (Exception e) {
                        Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                }
            }
        }
    }
    private void convertVideo (String fileName){
        progressDialog.show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                extension=formatSpinner.getSelectedItem().toString();
                String savePath="'/storage/emulated/0/Movies/"+fileName+"."+extension+"'";
                Log.w("chkPath",savePath);


                String strCommand ="-y -i '"+src_path+"' -vcodec copy -acodec copy "+savePath;

                Log.w(Config.TAG,"Command is = "+strCommand);

                long executionId = FFmpeg.executeAsync(strCommand, new ExecuteCallback() {
                    @Override
                    public void apply(final long executionId, final int returnCode) {

                        progressDialog.dismiss();
                        if (returnCode == RETURN_CODE_SUCCESS) {
                            Toast.makeText(ConvertActivity.this, "Video Saved in Folder : Movies", Toast.LENGTH_SHORT).show();
                            Log.i(Config.TAG, "Async command execution completed successfully.");
                        } else if (returnCode == RETURN_CODE_CANCEL) {
                            Log.i(Config.TAG, "Async command execution cancelled by user.");
                        } else {
                            Toast.makeText(ConvertActivity.this, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                            Log.i(Config.TAG, String.format("Async command execution failed with rc=%d.", returnCode));
                        }

                    }
                });

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Config.enableStatisticsCallback(new StatisticsCallback() {
                            public void apply(Statistics newStatistics) {
                                float progress = Float.parseFloat(String.valueOf(newStatistics.getTime())) / timeInMillisec;
                                float progressFinal = progress * 100;
                                Log.d(TAG, "Video Length: " + progressFinal);
                                Log.d(Config.TAG, String.format("frame: %d, time: %d", newStatistics.getVideoFrameNumber(), newStatistics.getTime()));
                                Log.d(Config.TAG, String.format("Quality: %f, time: %f", newStatistics.getVideoQuality(), newStatistics.getVideoFps()));
                                progressDialog.setProgress((int) progressFinal);
                            }
                        });
                    }
                });
            }

        }).start();
    }
}