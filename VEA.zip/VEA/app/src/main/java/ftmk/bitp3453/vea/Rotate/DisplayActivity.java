package ftmk.bitp3453.vea.Rotate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

import ftmk.bitp3453.vea.R;

public class DisplayActivity extends AppCompatActivity {

    VideoView displayVideo;
    Button uploadButton;
    private static final int SELECT_VIDEO_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        displayVideo = findViewById(R.id.displayVideo);
        uploadButton = findViewById(R.id.button_upload);

        // Set an OnClickListener on the Button
        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the gallery to select a video
                Intent intent = new Intent();
                intent.setType("video/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Video"), SELECT_VIDEO_REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SELECT_VIDEO_REQUEST_CODE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            // Get the selected video
            Uri videoUri = data.getData();
            // Set the selected video as the source for the VideoView
            displayVideo.setVideoURI(videoUri);

            // Create an Intent to start the second activity
            Intent intent = new Intent(DisplayActivity.this, RotateMainActivity.class);
            // Put the video Uri as an extra in the Intent
            intent.putExtra("video_uri", videoUri);
            //// Start the second activity
            startActivity(intent);
        }
    }
}