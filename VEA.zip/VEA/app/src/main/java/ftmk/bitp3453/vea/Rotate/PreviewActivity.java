package ftmk.bitp3453.vea.Rotate;

import static ftmk.bitp3453.vea.Rotate.RotateMainActivity.FILEPATH;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import ftmk.bitp3453.vea.R;

public class PreviewActivity extends AppCompatActivity {

    VideoView videoPreview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        videoPreview = findViewById(R.id.previewVidView);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        String filePath = getIntent().getStringExtra(FILEPATH);
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(videoPreview);
        videoPreview.setMediaController(mediaController);

        videoPreview.start();
    }
}