package ftmk.bitp3453.vea;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import ftmk.bitp3453.vea.Convert.ConvertActivity;
import ftmk.bitp3453.vea.Rotate.RotateMainActivity;
import ftmk.bitp3453.vea.Sound.EditSoundInterface;
import ftmk.bitp3453.vea.Trim.TrimMainActivity;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void gotoTrimAct(View view) {
        Intent intent = new Intent(this, MergeActivity.class);
        startActivity(intent);
    }

    public void gotoMergeAct(View view) {
        Intent intent = new Intent(this, TrimMainActivity.class);
        startActivity(intent);
    }

    public void gotoEditSoundAct(View view) {
        Intent intent = new Intent(this, EditSoundInterface.class);
        startActivity(intent);
    }

    public void gotoRotateAct(View view) {
        Intent intent = new Intent(this, RotateMainActivity.class);
        startActivity(intent);
    }

    public void gotoConvertAct(View view) {
        Intent intent = new Intent(this, ConvertActivity.class);
        startActivity(intent);
    }

}