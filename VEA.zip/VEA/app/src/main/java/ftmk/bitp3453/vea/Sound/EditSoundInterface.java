package ftmk.bitp3453.vea.Sound;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import ftmk.bitp3453.vea.databinding.ActivityEditSoundInterfaceBinding;

import ftmk.bitp3453.vea.R;

public class EditSoundInterface extends AppCompatActivity {

    ActivityEditSoundInterfaceBinding binding;
    Button btn_save, btn_load;
    EditSound editSound;
    int REQ_CODE_EXTERNAL_STORAGE_PERMISSION = 23;
    int last_action = 3;
private Uri uri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditSoundInterfaceBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        // calling the action bar
        ActionBar actionBar = getSupportActionBar();
        // showing the back button in action bar
        actionBar.setDisplayHomeAsUpEnabled(true);
        //show icon
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.drawable.edit_sound);
        btn_save = binding.btnSave;
        btn_load = binding.btnLoad;
        editSound = binding.cutterview;

        btn_save.setOnClickListener(v -> {
            last_action = 0;
            if(uri == null){
                Toast.makeText(EditSoundInterface.this, "Please Load Media File", Toast.LENGTH_SHORT).show();

            }else
                saveSoundFile();
        });

        btn_load.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(EditSoundInterface.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                last_action = 1;
                selectAudioFile();

            } else {
                ActivityCompat.requestPermissions(EditSoundInterface.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_CODE_EXTERNAL_STORAGE_PERMISSION);
            }
        });

    }
    private void selectAudioFile(){
        String[] mimetypes = {
                "audio/*",
                "video/*"
        };
        Intent intent = new Intent();
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimetypes); //Important part here
        intent.setAction(Intent.ACTION_GET_CONTENT);
        someActivityResultLauncher.launch(intent);
    }
    private void saveSoundFile(){
        LayoutInflater inflater = getLayoutInflater();
        final View view = inflater.inflate(R.layout.dialog_save_audio,null);
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Create a Soundboard");
        alertDialog.setCancelable(false);
        final EditText et_name = (EditText) view.findViewById(R.id.et_name);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.save), (dialog, which) -> {
            editSound.saveSound(et_name.getText().toString());

        });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.cancel), (dialog, which) -> alertDialog.dismiss());
        alertDialog.setView(view);
        alertDialog.show();
    }
    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    assert data != null;
                    uri = data.getData();

                    if (uri != null) {
                        editSound.setSound(uri,this,EditSoundInterface.this);
                    }else{
                        Toast.makeText(this, getResources().getString(R.string.error) + "Returned Uri is null", Toast.LENGTH_SHORT).show();
                    }

                }});

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQ_CODE_EXTERNAL_STORAGE_PERMISSION && grantResults.length >0 &&grantResults[0] == PackageManager.PERMISSION_GRANTED){
            if(last_action == 0){
                saveSoundFile();
            }else{
                selectAudioFile();
            }
        }
    }
}