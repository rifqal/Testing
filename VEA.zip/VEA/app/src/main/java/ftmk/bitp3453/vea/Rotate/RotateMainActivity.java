package ftmk.bitp3453.vea.Rotate;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static java.lang.String.format;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.LogCallback;
import com.arthenica.mobileffmpeg.LogMessage;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;

import java.io.File;
import java.util.Arrays;

import ftmk.bitp3453.vea.R;

public class RotateMainActivity extends AppCompatActivity {

    VideoView videoView;
    ImageView imageView;
    Button btn_rotate90, btn_rotate180, btn_rotate270,btn_custom;
    Uri uri;
    boolean isPlaying = false;
    String rotate = "90";
    File dest;
    String filePrefix, original_path, filePath;
    String[] command;
    public static final String FILEPATH = "filepath";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rotate_main);

        videoView = findViewById(R.id.videoView);
        imageView = findViewById(R.id.imageView);
        btn_rotate90 = findViewById(R.id.btn_rotate90);
        btn_rotate180 = findViewById(R.id.btn_rotate180);
        btn_rotate270 = findViewById(R.id.btn_rotate270);
        btn_custom = findViewById(R.id.btn_custom);

        Intent i = getIntent();

        if(i !=null) {
            // Get the video Uri from the Intent
            Uri videoUri = getIntent().getParcelableExtra("video_uri");
            // Set the video Uri as the source for the VideoView
            videoView.setVideoURI(videoUri);
            isPlaying = true;
            videoView.start();

        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isPlaying){
                    imageView.setImageResource(R.drawable.playbutton);
                    videoView.pause();
                    isPlaying = false;
                }
                else{
                    videoView.start();
                    imageView.setImageResource(R.drawable.pausebutton);
                    isPlaying = true;
                }
            }
        });

        btn_rotate90.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_rotate90.setEnabled(false);
                btn_rotate180.setEnabled(true);
                btn_rotate270.setEnabled(true);
                btn_custom.setEnabled(true);
                rotate = "90";
            }
        });

        btn_rotate180.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_rotate90.setEnabled(true);
                btn_rotate180.setEnabled(false);
                btn_rotate270.setEnabled(true);
                btn_custom.setEnabled(true);
                rotate = "180";
            }
        });

        btn_rotate270.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_rotate90.setEnabled(true);
                btn_rotate180.setEnabled(true);
                btn_rotate270.setEnabled(false);
                btn_custom.setEnabled(true);
                rotate = "270";
            }
        });

        btn_custom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dialog dialog = new Dialog(RotateMainActivity.this);
                dialog.setCanceledOnTouchOutside(false);
                dialog.requestWindowFeature(1);
                dialog.setContentView(R.layout.filename_popup);
                dialog.show();
                dialog.findViewById(R.id.closePopup).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                ((TextView)dialog.findViewById(R.id.Name)).setText("Enter Degree");
                final EditText editText = dialog.findViewById(R.id.message);
                dialog.findViewById(R.id.send_btn).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(editText.getText().toString().length() == 0){
                            Toast.makeText(RotateMainActivity.this, "Please Enter The Value Between 1 to 360", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        int parseInt = Integer.parseInt(editText.getText().toString());

                        if(parseInt<1 || parseInt>360){
                            Toast.makeText(RotateMainActivity.this, "Please Enter The Value Between 1 to 360", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        rotate = editText.getText().toString();
                        dialog.dismiss();
                    }
                });
            }
        });
    }
    public void VideoRotateCommand(){
        File folder = new File(Environment.getExternalStorageDirectory() + "/RotateVideo");
        if(!folder.exists()){
            folder.mkdirs();
        }
        String fileExt = ".mp4";
        dest = new File(folder, filePrefix + fileExt);
        original_path = getRealPathFromUri(getApplicationContext(), uri);
        filePath = dest.getAbsolutePath();
        StringBuilder sb3 = new StringBuilder();
        sb3.append("rotate=");
        sb3.append(this.rotate);
        sb3.append("*PI//180");

        command = new String[]{"-y","-i",original_path,"-filter_complex",sb3.toString(),"-c:a","copy",filePath};
        execffmpegBinary(command);

    }

    private String getRealPathFromUri(Context context, Uri contentUri){

        Cursor cursor = null;
        try{
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = context.getContentResolver().query(contentUri,proj,null,null,null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }finally {
            if(cursor !=null){
                cursor.close();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_picker, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem){
        if (menuItem.getItemId() == R.id.Done){
            final AlertDialog.Builder alert = new AlertDialog.Builder(RotateMainActivity.this);

            LinearLayout linearLayout = new LinearLayout(RotateMainActivity.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(50,0,50,100);
            final EditText input = new EditText(RotateMainActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.TOP | Gravity.START);
            input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            linearLayout.addView(input, lp);
            alert.setMessage("set video name");
            alert.setTitle("video name");
            alert.setView(linearLayout);
            alert.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            alert.setPositiveButton("submit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    filePrefix = input.getText().toString();
                    VideoRotateCommand();
                    dialogInterface.dismiss();
                }
            });
            alert.show();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void execffmpegBinary(final String[] command){
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();
        Config.enableLogCallback(new LogCallback() {
            @Override
            public void apply(LogMessage message) {
                Log.e(Config.TAG, message.getText());
            }
        });

        Config.enableLogCallback(new LogCallback() {
            @Override
            public void apply(LogMessage message) {
                Log.e(Config.TAG, message.getText());
            }
        });

        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics statistics) {

            }
        });
        Log.d(TAG, "Started command : ffmpeg" + Arrays.toString(command));

        long executionId = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {
                if(returnCode == RETURN_CODE_SUCCESS){
                    progressDialog.dismiss();
                    Intent intent = new Intent(RotateMainActivity.this, PreviewActivity.class);
                    intent.putExtra(FILEPATH, filePath);
                    startActivity(intent);
                } else if(returnCode == RETURN_CODE_CANCEL){
                    Log.e(Config.TAG, "Async command execution canceled by user");
                } else{
                    Log.e(Config.TAG, format("Async command execution failed with returncode = %d", returnCode));
                }
            }
        });
    }
}